import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux'
import Layout from '../layouts'
import { useStore } from '../store'
import Router from 'next/router'
import NProgress from 'nprogress'
import '../css/tailwind.css'
import '../css/main.css'
import '../css/animate.css'
import '../css/components/buttons.css'
import '../css/components/datepicker.css'
import '../css/components/dropdowns.css'
import '../css/components/forms.css'
import '../css/components/left-sidebar-1/styles-lg.css'
import '../css/components/left-sidebar-1/styles-sm.css'
import '../css/components/modals.css'
import '../css/components/navbar.css'
import '../css/components/nprogress.css'
import '../css/components/recharts.css'
import '../css/components/right-sidebar.css'
import '../css/components/sliders.css'
import '../css/components/steps.css'
import '../css/components/tables.css'
import '../css/components/tabs.css'
import '../css/components/user-widgets/widget-2.css'
import '../css/components/user-widgets/widget-4.css'
import '../css/layouts/layout-1.css'
import fetchData, { CONFIG } from '../api/api';
import { io } from "socket.io-client";

Router.events.on('routeChangeStart', () => NProgress.start())
Router.events.on('routeChangeComplete', () => NProgress.done())
Router.events.on('routeChangeError', () => NProgress.done())

export default function App({ Component, pageProps }) {
	const connectionOptions = {
		"force new connection": true,
		reconnectionAttempts: "Infinity",
		timeout: 10000,
		transports: ["websocket"]
	};
	const socket = io(CONFIG, connectionOptions);

	const [site_title, setsite_title] = useState('Lemoius | Admin Panel'),
		[faxicon_img, setfaxicon_img] = useState('http://lemoius.com:8000/uploads/images/settings/1617179365025.png');

	let get_data = (_id = '') => {
		let response = fetchData('/admin/settings/getdata', 'post', { _id });
		response.then((res) => {
			if (res && res.data && +res.data.status === 1) {
				if (res.data.response && res.data.response.site_title) {
					setsite_title(`${res.data.response.site_title} | Admin Panel - Lemoius`);
				}
				setfaxicon_img('http://lemoius.com:8000/uploads/images/settings/1617179365025.png');
			} else {
				setsite_title('');
			}
		}).catch((err) => {
			console.log("err", err)
			return toast.error('Something went wrong');
		})
	}

	useEffect(() => {
		socket.on("update_settings", data => {
			if (data && String(sessionStorage.getItem('user_sub_domain')) === String(data.user_sub_domain) && String(sessionStorage.getItem('user_id')) === String(data._id)) {
				get_data(data._id);
			} else if (data && data._id && String(data.role) !== String('admin') && String(data.role) !== String('salesperson') && String(sessionStorage.getItem('user_sub_domain')) !== String('admin')) {
				get_data(data._id);
			}
		});
	}, []);

	useEffect(() => {
		if (sessionStorage.getItem('user_sub_domain') && sessionStorage.getItem('user_id')) {
			get_data(sessionStorage.getItem('user_id'));
		} else {
			get_data();
		}
	}, []);

	const store = useStore(pageProps.initialReduxState)

	return (
		<>
			<Head>
				<title>{site_title}</title>
				<link rel="icon" href={faxicon_img} />
				<meta
					name="viewport"
					content="width=device-width, initial-scale=1, shrink-to-fit=no"
				/>
				<script src="https://cdn.tiny.cloud/1/ykix580tx0voe8sbmz32a7zhuo5w65vvp73i0cmc7qqeqsfg/tinymce/5/tinymce.min.js" referrerPolicy="origin"></script>
			</Head>
			<Provider store={store}>
				<Layout>
					<Component {...pageProps} />
				</Layout>
			</Provider>
		</>
	)
}
