import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import fetchData, { CONFIG } from "../api/api";
import { withRouter } from 'next/router'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { io } from "socket.io-client";
const connectionOptions = {
	"force new connection": true,
	reconnectionAttempts: "Infinity",
	timeout: 10000,
	transports: ["websocket"]
};
const socket = io(CONFIG, connectionOptions);

const EmailConfirmation = (props) => {

	let log_out = () => {
		let response = fetchData('/admin/logout', 'post', {});
		response.then((res) => {
			if (res && res.data && String(res.data.status) === '00') {
				return props.router.push('/login')
			}
			if (res && res.data && +res.data.status === 0) {
				if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
					res.data.errors.map((item) => {
						return toast.error(item.msg);
					})
				} else {
					toast.error(res.data.response);
				}
			} else {
				if (res && res.data && +res.data.status === 1) {
					toast.success(res.data.response);
					localStorage.removeItem('SGH');
					sessionStorage.removeItem('SGH');
					sessionStorage.removeItem('user_id');
					sessionStorage.removeItem('user_sub_domain')
					setTimeout(() => {
						return props.router.push('/login')
					}, 1500);
				}
			}
		}).catch((err) => {
			console.log("err", err)
			return toast.error('Something went wrong');
			// return props.router.push('/login');
		});
	};


	useEffect(() => {
		socket.on("profile_password_updated", data => {
			if (data && String(data._id) === String(sessionStorage.getItem('user_id'))) {
				setTimeout(() => {
					toast.info('Password changed');
					log_out();
				}, 1000);
			}
		});
	}, [])


	useEffect(() => {
		socket.on("client_logout", data => {
			if (data && String(data._id) === String(sessionStorage.getItem('user_id'))) {
				setTimeout(() => {
					toast.info('Your Account Is Currently Inactivated, Please Contact Admin');
					log_out();
				}, 1000);
			}
		});
	}, [])

	useEffect(() => {
		socket.on("salesperson_logout", data => {
			if (data && String(data._id) === String(sessionStorage.getItem('user_id'))) {
				setTimeout(() => {
					toast.info('Your Account Is Currently Inactivated, Please Contact Admin');
					log_out();
				}, 1000);
			}
		});
	}, [])

	useEffect(() => {
		log_out();
	}, [])

	return (
		<>
			<ToastContainer position="top-right" autoClose={2500} closeOnClick />
			<div className="flex flex-col w-full max-w-xl text-center">
				<img
					className="object-contain w-auto h-64 mb-8"
					src="/images/illustration.svg"
					alt="svg"
				/>
				<div className="mb-8 text-center text-grey-900">
					You have succesfully signed out.
      </div>
				<div className="flex w-full">
					<Link href="/login">
						<a className="btn btn-lg btn-rounded btn-block bg-blue-500 hover:bg-blue-600 text-white">
							Go back
          </a>
					</Link>
				</div>
			</div>
		</>
	)
}

export default withRouter(EmailConfirmation)
