import React, { useState, useEffect } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import Layout from '../layouts/centered'
import CenteredForm from '../layouts/centered-form'
import fetchData from "../api/api";


const Index = (props) => {
	const [domain, setdomain] = useState(''),
		[domain_err, setdomain_err] = useState(false),
		[clicked, setclicked] = useState(false);


	let onChange = (e, name) => {
		if (String(name) === String('domain')) {
			if (!e.target.value) {
				setdomain_err(true);
			} else {
				setdomain_err(false);
			}
			setdomain(String(e.target.value).toLowerCase());
		}
	};

	let submit = (e) => {
		e.preventDefault();
		if (!domain) {
			setdomain_err(true);
			return toast.error('Workspace is required');
		}
		if (domain_err) {
			return toast.error('Workspace is required');
		}
		setclicked(true);
		if (String(domain) === String('admin')) {
			setclicked(false);
			return window.location.replace(`${window.location.protocol}//admin.${window.location.host}/login`);
		}
		if (String(domain) === String('salespartner')) {
			setclicked(false);
			return window.location.replace(`${window.location.protocol}//salespartner.${window.location.host}/login`);
		}

		let response = fetchData('/admin/check/workspace', 'post', { domain });
		response.then(res => {
			if (res && res.data && +res.data.status === 0) {
				setclicked(false);
				if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
					res.data.errors.map((item) => {
						return toast.error(item.msg);
					})
				} else {
					setclicked(false);
					toast.error(res.data.response);
				}
			} else {
				if (res && res.data && +res.data.status === 1) {
					toast.success(res.data.response);
					return window.location.replace(`${window.location.protocol}//${domain}.${window.location.host}/login`);
				}
			}
		}).catch(err => {
			setclicked(false);
			console.log("err", err)
			return toast.error('Something went wrong');
		});
	};


	useEffect(() => {
		setdomain('');
		setdomain_err(false);
		let length = window.location.host.split('.');
        if (length && length.length > 1) {
			return window.location.replace(`${window.location.protocol}//${length[0]}.${window.location.host}/login`);
        }
		return () => {
			setdomain('');
			setdomain_err(false);
		}
	}, []);

	return (
		<Layout>
			<ToastContainer position="top-right" autoClose={2500} closeOnClick />
			<CenteredForm title="" subtitle="Enter Your Workspace Here">
				<form>
					<div className="flex flex-col lg:flex-row lg:flex-wrap w-full lg:space-x-4">
						<div className="w-full mt-3 mb-6">
							<div className={`form-element`}>
								<div className="form-label">Workspace <span className="form-error">*</span></div>
								<input
									name="domain"
									type="text"
									className={`form-input form-input-${domain_err ? 'invalid' : 'valid'}`}
									placeholder="Enter Workspace"
									value={domain}
									onChange={e => onChange(e, 'domain')}
								/>
								{domain_err ? <div className="form-error">Workspace is required</div> : null}
							</div>
						</div>
					</div>
					{clicked ?
						<button
							type="submit"
							className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
							disabled={clicked}
							style={{ cursor: 'progress' }}>Continue </button> :
						<button
							type="submit"
							className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
							onClick={e => submit(e)}>Continue </button>
					}
				</form>
			</CenteredForm>
		</Layout>
	)
}

export default Index
