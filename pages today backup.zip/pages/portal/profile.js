import React, { useState, useEffect } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Widget from '../components/widget'
import fetchData from "../api/api";
import SectionTitle from '../components/section-title'
import { useRouter } from 'next/router';
import Link from 'next/link'
import {
    FiHome,
    FiChevronRight,
    FiChevronsRight,
    FiArrowRight
} from 'react-icons/fi';

const Index = props => {
    let router = useRouter();
    let [name, setName] = useState(''),
        [name_err, setName_err] = useState(false),
        [username, setusername] = useState(''),
        [username_err, setusername_err] = useState(false),
        [email, setemail] = useState(''),
        [email_err, setemail_err] = useState(false),
        [password, setpassword] = useState(''),
        [password_err, setpassword_err] = useState(false),
        [confirm_password, setconfirm_password] = useState(''),
        [confirm_password_err, setconfirm_password_err] = useState(false),
        [phone, setphone] = useState(''),
        [phone_err, setphone_err] = useState(false),
        [invalid_email, setinvalid_email] = useState(false),
        [invalid_phone, setinvalid_phone] = useState(false),
        [passwod_mis_match, setpasswod_mis_match] = useState(false),
        [clicked, setclicked] = useState(false),
        [selected_id, setselected_id] = useState('');

    let validateEmail = (email) => {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    };

    let validatephone = (phone) => {
        const re = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
        return re.test(String(phone).toLowerCase());
    };

    let home = false, icon = 'arrow', items = [
        { title: 'Home', url: '/dashboard', last: false },
        { title: 'Profile', url: '/profile', last: true }
    ];

    let get_edit_data = _id => {
        if (_id && _id.length > 0 && String(_id) !== String(undefined)) {
            setselected_id(_id)
            let response = fetchData('/admin/common/profile/get', 'post', { _id });
            response.then((res) => {
                if (res && res.data && String(res.data.status) === '00') {
                    return router.push('/login')
                }
                if (res && res.data && +res.data.status === 0) {
                    if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                        res.data.errors.map((item) => {
                            return toast.error(item.msg);
                        })
                    }
                } else {
                    if (res && res.data && +res.data.status === 1) {
                        window.scrollTo(0, 0);
                        setName(res.data.response && res.data.response.name ? res.data.response.name : '');
                        setusername(res.data.response && res.data.response.username ? res.data.response.username : '');
                        setemail(res.data.response && res.data.response.email ? res.data.response.email : '');
                        setphone(res.data.response && res.data.response.phone ? res.data.response.phone : '');
                    }
                }
            }).catch((err) => {
                console.log("err", err)
                return toast.error('Something went wrong');
            });
        }
    };

    let onChange = (e, name) => {
        if (String(name) === String('name')) {
            if (!e.target.value) {
                setName_err(true);
            } else {
                setName_err(false);
            }
            setName(e.target.value);
        }
        if (String(name) === String('username')) {
            if (!e.target.value) {
                setusername_err(true);
            } else {
                setusername_err(false);
            }
            setusername(e.target.value);
        }
        if (String(name) === String('email')) {
            if (!e.target.value) {
                setemail_err(true);
            } else {
                setemail_err(false);
            }
            if (!validateEmail(e.target.value)) {
                setinvalid_email(true);
            } else {
                setinvalid_email(false);
            }
            setemail(e.target.value);
        }
        if (String(name) === String('phone')) {
            if (!e.target.value) {
                setphone_err(true);
            } else {
                setphone_err(false);
            }
            if (!validatephone(e.target.value)) {
                setinvalid_phone(true);
            } else {
                setinvalid_phone(false);
            }
            setphone(e.target.value);
        }
        if (String(name) === String('password')) {
            setpassword(e.target.value);
        }
        if (String(name) === String('confirm_password')) {
            if (String(e.target.value) !== String(password)) {
                setpasswod_mis_match(true);
            } else {
                setpasswod_mis_match(false);
            }
            setconfirm_password(e.target.value);
        }
    };

    let submit = (e) => {
        e.preventDefault();
        if (!name) {
            setName_err(true);
            return toast.error('Name is required')
        }
        if (name_err) {
            return toast.error('Name is required')
        }
        if (!username) {
            setusername_err(true);
            return toast.error('Username is required')
        }
        if (username_err) {
            return toast.error('Username is required')
        }
        if (!email) {
            setemail_err(true);
            return toast.error('Email is required')
        }
        if (email_err) {
            return toast.error('Email is required')
        }
        if (!validateEmail(email)) {
            setinvalid_email(true);
            return toast.error('Invalid Email')
        }
        if (!phone) {
            setphone_err(true);
            return toast.error('Mobile number is required')
        }
        if (phone_err) {
            return toast.error('Mobile number is required')
        }
        if (!validatephone(phone)) {
            setinvalid_phone(true);
            return toast.error('Mobile number should contains only 10 digits')
        }
        if (!selected_id) {
            if (!password) {
                setpassword_err(true);
                return toast.error('Password is required')
            }
            if (password_err) {
                return toast.error('Password is required')
            }
            if (String(password) !== String(confirm_password)) {
                setconfirm_password_err(true);
                return toast.error('Password and Confirm password should be same');
            }
            if (!confirm_password) {
                setconfirm_password_err(true);
                return toast.error('Confirm password is required')
            }
            if (confirm_password_err) {
                return toast.error('Confirm password is required')
            }
        }
        setclicked(true);
        let data = {
            name, email, username, phone, password,
            _id: selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? selected_id : ''
        };
        let response = fetchData('/admin/common/profile/update', 'post', data);
        response.then((res) => {
            setclicked(false);
            if (res && res.data && String(res.data.status) === '00') {
                return router.push('/login')
            }
            if (res && res.data && +res.data.status === 0) {
                if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                    res.data.errors.map((item) => {
                        return toast.error(item.msg);
                    })
                } else {
                    toast.error(res.data.response);
                }
            } else {
                if (res && res.data && +res.data.status === 1) {
                    toast.success(res.data.response);
                    setpassword('')
                    setconfirm_password('')
                }
            }
        }).catch((err) => {
            console.log("err", err)
            return toast.error('Something went wrong');
        })
    };

    useEffect(() => {
        setpassword('')
        setconfirm_password('')
        let length = window.location.host.split('.');
        if (length && length.length > 1) {
            if (!sessionStorage.getItem('user_sub_domain')) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                sessionStorage.removeItem('user_sub_domain')
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(sessionStorage.getItem('user_sub_domain'))) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(length[0])) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            }
        } else {
            sessionStorage.removeItem('set_domain');
            sessionStorage.removeItem('user_sub_domain')
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('SGH');
            sessionStorage.removeItem('set_domain');
            return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
        }
    }, []);

    useEffect(() => {
        setpassword('')
        setconfirm_password('')
        if (sessionStorage.getItem('user_id') && sessionStorage.getItem('user_id').length > 0 && sessionStorage.getItem('user_id') !== undefined && sessionStorage.getItem('user_id') !== null) {
            get_edit_data(sessionStorage.getItem('user_id'))
        } else {
            sessionStorage.removeItem('user_sub_domain')
            sessionStorage.removeItem('user_id');
            sessionStorage.removeItem('SGH');
            sessionStorage.removeItem('set_domain');
        }
    }, []);

    return (
        <>
            <ToastContainer position="top-right" autoClose={2500} closeOnClick />
            <div className="flex flex-row mb-4">
                <div className="w-full">
                    <nav className="w-full flex">
                        <ol className="list-none flex flex-row items-center justify-start">
                            {home && (
                                <li className="mr-2 flex items-center">
                                    <FiHome className="h-3 w-3 stroke-current" />
                                </li>
                            )}
                            {items.map((item, i) => (
                                <li className="flex items-center" key={i}>
                                    <Link href={item.url}>
                                        <a className="mr-2">{item.title}</a>
                                    </Link>
                                    {!item.last && icon === 'arrow' && (
                                        <FiArrowRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevron' && (
                                        <FiChevronRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevrons' && (
                                        <FiChevronsRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                </li>
                            ))}
                        </ol>
                    </nav>
                </div>
            </div>
            <SectionTitle style={{ textTransform: 'capitalize' }} title="" subtitle={selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? 'Update Profile' : "Update Profile"} />
            <Widget title="">
                <form>
                    <div className="flex flex-col lg:flex-row lg:flex-wrap w-full lg:w-1/2">
                        <div className="w-full mt-3 mb-6">
                            <div className={`form-element`}>
                                <div className="form-label">Name <span className="form-error">*</span></div>
                                <input
                                    name="name"
                                    type="text"
                                    className={`form-input form-input-${name_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter name"
                                    value={name}
                                    onChange={e => onChange(e, 'name')}
                                />
                                {name_err ? <div className="form-error">Name is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Username <span className="form-error">*</span></div>
                                <input
                                    name="username"
                                    type="text"
                                    className={`form-input form-input-${username_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter username"
                                    value={username}
                                    onChange={e => onChange(e, 'username')}
                                />
                                {username_err ? <div className="form-error">Username is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Email <span className="form-error">*</span></div>
                                <input
                                    name="email"
                                    type="email"
                                    required={true}
                                    className={`form-input form-input-${email_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter email"
                                    value={email}
                                    onChange={e => onChange(e, 'email')}
                                />
                                {email_err ? <div className="form-error">Email is required</div> : null}
                                {invalid_email ? <div className="form-error">Invalid email</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Mobile Number <span className="form-error">*</span></div>
                                <input
                                    name="phone"
                                    type="number"
                                    className={`form-input form-input-${phone_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter mobile number"
                                    value={phone}
                                    maxLength={10}
                                    max={10}
                                    required={true}
                                    onChange={e => onChange(e, 'phone')}
                                />
                                {phone_err ? <div className="form-error">Mobile Number is required</div> : null}
                                {invalid_phone ? <div className="form-error">Mobile number should contains only 10 digits</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Password {selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? null : <span className="form-error">*</span>} </div>
                                <input
                                    name="password"
                                    type="password"
                                    className={`form-input form-input-${password_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter password"
                                    value={password}
                                    min={6}
                                    minLength={6}
                                    onChange={e => onChange(e, 'password')}
                                />
                                {password_err ? <div className="form-error">Password is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Confirm Password {selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? null : <span className="form-error">*</span>}</div>
                                <input
                                    name="confirm_password"
                                    type="password"
                                    className={`form-input form-input-${confirm_password_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter Confirm Password"
                                    value={confirm_password}
                                    min={6}
                                    minLength={6}
                                    onChange={e => onChange(e, 'confirm_password')}
                                />
                                {confirm_password_err ? <div className="form-error">Confirm Password is required</div> : null}
                                {passwod_mis_match ? <div className="form-error">Password and Confirm Password should same</div> : null}
                            </div>
                        </div>
                        <div style={{ marginLeft: '449px' }}>
                            {clicked ?
                                <button
                                    className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                                    style={{ cursor: 'progress' }}
                                    disabled={clicked}
                                >{selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? 'Update' : "Submit"} </button>
                                :
                                <>
                                    <button
                                        className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                                        onClick={e => submit(e)}
                                        disabled={clicked}
                                    >{selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? 'Update' : "Submit"} </button>
                                </>
                            }
                        </div>
                    </div>
                </form>
            </Widget>
        </>
    )

};
export default Index;
