import React, { useState, useEffect } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Widget from '../components/widget'
import Widget1 from '../components/dashboard/widget-1'
import fetchData from "../api/api";
import Switch from 'react-switch'
import { useSelector, shallowEqual } from 'react-redux';
import { FiEye, FiEdit, FiTrash, FiX, FiSearch, FiThumbsUp, FiThumbsDown, FiToggleRight, FiToggleLeft, FiRefreshCw } from 'react-icons/fi'
import { Popover, PopoverHeader, PopoverBody, Pagination, PaginationLink, PaginationItem } from "reactstrap";
import { useRouter } from 'next/router';
import Link from 'next/link'
import {
    FiHome,
    FiChevronRight,
    FiChevronsRight,
    FiArrowRight
} from 'react-icons/fi';
import { FaSortNumericDown, FaSortNumericUp } from 'react-icons/fa';
import { getColor } from '../functions/colors'
import { _ } from 'core-js';
import SectionTitle from '../components/section-title'

const Index = props => {
    let router = useRouter();
    let [name, setName] = useState(''),
        [name_err, setName_err] = useState(false),
        [username, setusername] = useState(''),
        [username_err, setusername_err] = useState(false),
        [email, setemail] = useState(''),
        [email_err, setemail_err] = useState(false),
        [password, setpassword] = useState(''),
        [password_err, setpassword_err] = useState(false),
        [confirm_password, setconfirm_password] = useState(''),
        [confirm_password_err, setconfirm_password_err] = useState(false),
        [phone, setphone] = useState(''),
        [phone_err, setphone_err] = useState(false),
        [status, setstatus] = useState('1'),
        [status_err, setstatus_err] = useState(false),
        [address, setaddress] = useState(''),
        [notes, setnotes] = useState(''),
        [invalid_email, setinvalid_email] = useState(false),
        [invalid_phone, setinvalid_phone] = useState(false),
        [passwod_mis_match, setpasswod_mis_match] = useState(false),
        [clicked, setclicked] = useState(false),
        [selected_id, setselected_id] = useState('');

    const { palettes } = useSelector((state) => ({ palettes: state.palettes }), shallowEqual)
    let { background } = { ...palettes };

    let validateEmail = (email) => {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    };

    let validatephone = (phone) => {
        const re = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
        return re.test(String(phone).toLowerCase());
    };

    let home = false, icon = 'arrow', items = [
        { title: 'Home', url: '/dashboard', last: false },
        { title: 'Add Sales Partner', url: '/salespartner-add', last: true }
    ];

    let clear_for = (e) => {
        e.preventDefault();
        setstatus(''); setstatus_err(false);
        setName(''); setName_err(false);
        setusername(''); setusername_err(false);
        setemail(''); setemail_err(false);
        setpassword(''); setpassword_err(false);
        setconfirm_password(''); setconfirm_password_err(false);
        setphone(''); setphone_err(false);
        setaddress(''); setnotes('');
        setselected_id('');
        if (selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null)) {
            sessionStorage.removeItem('salespartner_id');
            return router.push('/salespartner-list');
        }
    };

    let get_edit_data = (_id) => {
        if (_id && _id.length > 0 && String(_id) !== String(undefined)) {
            setselected_id(_id)
            let response = fetchData('/admin/salesperson/edit', 'post', { _id });
            response.then((res) => {
                if (res && res.data && String(res.data.status) === '00') {
                    return router.push('/login')
                }
                if (res && res.data && +res.data.status === 0) {
                    if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                        res.data.errors.map((item) => {
                            return toast.error(item.msg);
                        })
                    }
                } else {
                    if (res && res.data && +res.data.status === 1) {
                        window.scrollTo(0, 0);
                        setName(res.data.response && res.data.response.name ? res.data.response.name : '');
                        setusername(res.data.response && res.data.response.username ? res.data.response.username : '');
                        setemail(res.data.response && res.data.response.email ? res.data.response.email : '');
                        setphone(res.data.response && res.data.response.phone ? res.data.response.phone : '');
                        setaddress(res.data.response && res.data.response.address ? res.data.response.address : '');
                        setnotes(res.data.response && res.data.response.notes ? res.data.response.notes : '');
                        setstatus(res.data.response && res.data.response.status ? res.data.response.status : '');
                    }
                }
            }).catch((err) => {
                console.log("err", err)
                return toast.error('Something went wrong');
            });
        }
    };

    let onChange = (e, name) => {
        if (String(name) === String('name')) {
            if (!e.target.value) {
                setName_err(true);
            } else {
                setName_err(false);
            }
            setName(e.target.value);
        }
        if (String(name) === String('username')) {
            if (!e.target.value) {
                setusername_err(true);
            } else {
                setusername_err(false);
            }
            setusername(e.target.value);
        }
        if (String(name) === String('email')) {
            if (!e.target.value) {
                setemail_err(true);
            } else {
                setemail_err(false);
            }
            if (!validateEmail(e.target.value)) {
                setinvalid_email(true);
            } else {
                setinvalid_email(false);
            }
            setemail(e.target.value);
        }
        if (String(name) === String('phone')) {
            if (!e.target.value) {
                setphone_err(true);
            } else {
                setphone_err(false);
            }
            if (!validatephone(e.target.value)) {
                setinvalid_phone(true);
            } else {
                setinvalid_phone(false);
            }
            setphone(e.target.value);
        }
        if (String(name) === String('address')) {
            setaddress(e.target.value);
        }
        if (String(name) === String('notes')) {
            setnotes(e.target.value);
        }
        if (String(name) === String('password')) {
            if (!e.target.value) {
                setpassword_err(true);
            } else {
                setpassword_err(false);
            }
            setpassword(e.target.value);
        }
        if (String(name) === String('confirm_password')) {
            if (!e.target.value) {
                setconfirm_password_err(true);
            } else {
                setconfirm_password_err(false);
            }
            if (String(e.target.value) !== String(password)) {
                setpasswod_mis_match(true);
            } else {
                setpasswod_mis_match(false);
            }
            setconfirm_password(e.target.value);
        }
        if (String(name) === String('status')) {
            if (!e.target.value) {
                setstatus_err(true);
            } else {
                setstatus_err(false);
            }
            setstatus(e.target.value);
        }
    };

    let submit = (e) => {
        e.preventDefault();
        if (!name) {
            setName_err(true);
            return toast.error('Name is required')
        }
        if (name_err) {
            return toast.error('Name is required')
        }
        if (!username) {
            setusername_err(true);
            return toast.error('Username is required')
        }
        if (username_err) {
            return toast.error('Username is required')
        }
        if (!email) {
            setemail_err(true);
            return toast.error('Email is required')
        }
        if (email_err) {
            return toast.error('Email is required')
        }
        if (!validateEmail(email)) {
            setinvalid_email(true);
            return toast.error('Invalid Email')
        }
        if (!phone) {
            setphone_err(true);
            return toast.error('Mobile number is required')
        }
        if (phone_err) {
            return toast.error('Mobile number is required')
        }
        if (!validatephone(phone)) {
            setinvalid_phone(true);
            return toast.error('Mobile number should contains only 10 digits')
        }
        if (!selected_id) {
            if (!password) {
                setpassword_err(true);
                return toast.error('Password is required')
            }
            if (password_err) {
                return toast.error('Password is required')
            }
            if (String(password) !== String(confirm_password)) {
                setconfirm_password_err(true);
                return toast.error('Password and Confirm password should be same');
            }
            if (!confirm_password) {
                setconfirm_password_err(true);
                return toast.error('Confirm password is required')
            }
            if (confirm_password_err) {
                return toast.error('Confirm password is required')
            }
        }
        if (!status) {
            setstatus_err(true);
            return toast.error('Status is required')
        }
        if (status_err) {
            return toast.error('Status is required')
        }
        setclicked(true);
        let data = {
            name, email, username, phone, password, status, address, notes,
            _id: selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? selected_id : ''
        };
        let response = fetchData('/admin/salesperson/add', 'post', data);
        response.then((res) => {
            setclicked(false);
            if (res && res.data && String(res.data.status) === '00') {
                return router.push('/login')
            }
            if (res && res.data && +res.data.status === 0) {
                if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                    res.data.errors.map((item) => {
                        return toast.error(item.msg);
                    })
                } else {
                    toast.error(res.data.response);
                }
            } else {
                if (res && res.data && +res.data.status === 1) {
                    toast.success(res.data.response);
                    setTimeout(() => {
                        setstatus(''); setstatus_err(false);
                        setName(''); setName_err(false);
                        setusername(''); setusername_err(false);
                        setemail(''); setemail_err(false);
                        setpassword(''); setpassword_err(false);
                        setconfirm_password(''); setconfirm_password_err(false);
                        setphone(''); setphone_err(false);
                        setaddress(''); setnotes('');
                        setselected_id('');
                        if (selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null)) {
                            sessionStorage.removeItem('salespartner_id');
                        }
                        return router.push('/salespartner-list');
                    }, 1000);
                }
            }
        }).catch((err) => {
            console.log("err", err)
            return toast.error('Something went wrong');
        })
    };

    useEffect(() => {
        if (sessionStorage.getItem('salespartner_id') && sessionStorage.getItem('salespartner_id').length > 0 && sessionStorage.getItem('salespartner_id') !== undefined && sessionStorage.getItem('salespartner_id') !== null) {
            get_edit_data(sessionStorage.getItem('salespartner_id'), 'edit')
        }
        return () => {
            sessionStorage.removeItem('salespartner_id');
        };
    }, []);

    useEffect(() => {
        let length = window.location.host.split('.');
        if (length && length.length > 1) {
            if (!sessionStorage.getItem('user_sub_domain')) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                sessionStorage.removeItem('user_sub_domain')
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(sessionStorage.getItem('user_sub_domain'))) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(length[0])) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            }
        } else {
            sessionStorage.removeItem('set_domain');
            return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
        }
    }, []);

    return (
        <>
            <ToastContainer position="top-right" autoClose={2500} closeOnClick />
            <div className="flex flex-row mb-4">
                <div className="w-full">
                    <nav className="w-full flex">
                        <ol className="list-none flex flex-row items-center justify-start">
                            {home && (
                                <li className="mr-2 flex items-center">
                                    <FiHome className="h-3 w-3 stroke-current" />
                                </li>
                            )}
                            {items.map((item, i) => (
                                <li className="flex items-center" key={i}>
                                    <Link href={item.url}>
                                        <a className="mr-2">{item.title}</a>
                                    </Link>
                                    {!item.last && icon === 'arrow' && (
                                        <FiArrowRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevron' && (
                                        <FiChevronRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevrons' && (
                                        <FiChevronsRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                </li>
                            ))}
                        </ol>
                    </nav>
                </div>
            </div>
            <SectionTitle style={{ textTransform: 'capitalize' }} title="" subtitle={selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? 'Edit Sales Partner' : "Add Sales Partner"} />
            <Widget title="">
                <form>
                    <div className="flex flex-col lg:flex-row lg:flex-wrap w-full lg:w-1/2">
                        <div className="w-full mt-3 mb-6">
                            <div className={`form-element`}>
                                <div className="form-label">Name <span className="form-error">*</span></div>
                                <input
                                    name="name"
                                    type="text"
                                    className={`form-input form-input-${name_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter name"
                                    value={name}
                                    onChange={e => onChange(e, 'name')}
                                />
                                {name_err ? <div className="form-error">Name is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Username <span className="form-error">*</span></div>
                                <input
                                    name="username"
                                    type="text"
                                    className={`form-input form-input-${username_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter username"
                                    value={username}
                                    onChange={e => onChange(e, 'username')}
                                />
                                {username_err ? <div className="form-error">Username is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Email <span className="form-error">*</span></div>
                                <input
                                    name="email"
                                    type="email"
                                    required={true}
                                    className={`form-input form-input-${email_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter email"
                                    value={email}
                                    onChange={e => onChange(e, 'email')}
                                />
                                {email_err ? <div className="form-error">Email is required</div> : null}
                                {invalid_email ? <div className="form-error">Invalid email</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Mobile Number <span className="form-error">*</span></div>
                                <input
                                    name="phone"
                                    type="number"
                                    className={`form-input form-input-${phone_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter mobile number"
                                    value={phone}
                                    maxLength={10}
                                    max={10}
                                    required={true}
                                    onChange={e => onChange(e, 'phone')}
                                />
                                {phone_err ? <div className="form-error">Mobile Number is required</div> : null}
                                {invalid_phone ? <div className="form-error">Mobile number should contains only 10 digits</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Address </div>
                                <textarea
                                    name="address"
                                    type="textarea"
                                    className={`form-input form-input-valid`}
                                    placeholder="Enter address"
                                    value={address}
                                    maxLength={250}
                                    required={true}
                                    onChange={e => onChange(e, 'address')}
                                />
                                <span> {String(address).length} / 250 </span>
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Notes </div>
                                <textarea
                                    name="notes"
                                    type="textarea"
                                    className={`form-input form-input-valid`}
                                    placeholder="Enter notes"
                                    value={notes}
                                    maxLength={250}
                                    required={true}
                                    onChange={e => onChange(e, 'notes')}
                                />
                                <span> {String(notes).length} / 250 </span>
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Password {selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? null : <span className="form-error">*</span>} </div>
                                <input
                                    name="password"
                                    type="password"
                                    className={`form-input form-input-${password_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter password"
                                    value={password}
                                    min={6}
                                    minLength={6}
                                    onChange={e => onChange(e, 'password')}
                                />
                                {password_err ? <div className="form-error">Password is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Confirm Password {selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) && String(selected_id) !== String(null) ? null : <span className="form-error">*</span>}</div>
                                <input
                                    name="confirm_password"
                                    type="password"
                                    className={`form-input form-input-${confirm_password_err ? 'invalid' : 'valid'}`}
                                    placeholder="Enter Confirm Password"
                                    value={confirm_password}
                                    min={6}
                                    minLength={6}
                                    onChange={e => onChange(e, 'confirm_password')}
                                />
                                {confirm_password_err ? <div className="form-error">Confirm Password is required</div> : null}
                                {passwod_mis_match ? <div className="form-error">Password and Confirm Password should same</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Status <span className="form-error">*</span> </div>
                                <select name="status" value={status} onChange={e => onChange(e, 'status')} className={`form-input form-input-${status_err ? 'invalid' : 'valid'}`} >
                                    <option value="" >Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="2" >In-Active</option>
                                </select>
                                {status_err ? <div className="form-error">Status is required</div> : null}
                            </div>
                        </div>
                        <div style={{ marginLeft: '378px' }}>
                            {clicked ?
                                <button
                                    className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                                    style={{ cursor: 'progress' }}
                                    disabled={clicked}
                                >{selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? 'Update' : "Submit"} </button>
                                :
                                <>
                                    <button
                                        className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                                        onClick={e => submit(e)}
                                        disabled={clicked}
                                        style={{ marginLeft: '-4px' }}
                                    >{selected_id && selected_id.length > 0 && String(selected_id) !== String(undefined) ? 'Update' : "Submit"} </button>
                                    {' '}
                                    <button
                                        className="btn btn-default bg-red-500 hover:bg-red-600 text-white btn-rounded"
                                        onClick={e => clear_for(e)}
                                    >Reset </button>
                                </>
                            }
                        </div>
                    </div>
                </form>
            </Widget>
        </>
    )
};

export default Index;