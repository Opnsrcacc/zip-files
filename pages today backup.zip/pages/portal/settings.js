import React, { useState, useEffect } from 'react'
import moment from 'moment';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Widget from '../components/widget'
import fetchData, { CONFIG } from "../api/api";
import SectionTitle from '../components/section-title'
import Datetime from 'react-datetime';
import Widget1 from '../components/dashboard/widget-1'
import { FiEye, FiEdit, FiTrash, FiX, FiSearch, FiToggleLeft, FiToggleRight } from 'react-icons/fi'
import { useSelector, shallowEqual } from 'react-redux';
import { Popover, PopoverHeader, PopoverBody, Pagination, PaginationLink, PaginationItem } from "reactstrap";
import { useRouter } from 'next/router';
import Link from 'next/link'
import {
    FiHome,
    FiChevronRight,
    FiChevronsRight,
    FiArrowRight
} from 'react-icons/fi'
import { FaSortNumericDown, FaSortNumericUp } from 'react-icons/fa'
import { Editor } from "@tinymce/tinymce-react";

const Index = () => {
    let router = useRouter();
    let [clicked, setclicked] = useState(false),
        [domain_err, setdomain_err] = useState(''),
        [site_title, setsite_title] = useState(''),
        [site_title_err, setsite_title_err] = useState(false),
        [navigation_title, setnavigation_title] = useState(''),
        [navigation_title_err, setnavigation_title_err] = useState(''),
        [navigationlogo, setnavigationlogo] = useState(''),
        [navigationlogo_err, setnavigationlogo_err] = useState(false),
        [shownavigationlogo, showsetnavigationlogo] = useState(false),
        [favicon, setfavicon] = useState(''),
        [favicon_err, setfavicon_err] = useState(false),
        [showfavicon, showsetfavicon] = useState(false),
        [selected_id, setselected_id] = useState('');

    const { palettes } = useSelector((state) => ({ palettes: state.palettes }), shallowEqual)
    let { background } = { ...palettes };

    let home = false, icon = 'arrow', items = [
        { title: 'Home', url: '/dashboard', last: false },
        { title: 'Admin Setting', url: '/setting', last: false }
    ];

    let onChange = (e, name) => {
        if (String(name) === String('site_title')) {
            if (!e.target.value) {
                setsite_title_err(true);
            } else {
                setsite_title_err(false);
            }
            setsite_title(e.target.value);
        }
        if (String(name) === String('navigation_title')) {
            if (!e.target.value) {
                setnavigation_title_err(true);
            } else {
                setnavigation_title_err(false);
            }
            setnavigation_title(e.target.value);
        }
    };

    let onFileChange = (fileChangeEvent, from) => {
        if (from == 'logo') {
            setnavigationlogo(fileChangeEvent.target.files[0]);
            showsetnavigationlogo(false);
        } else if (from == 'favicon') {
            setfavicon(fileChangeEvent.target.files[0]);
            showsetfavicon(false);
        }
    }

    let submit = (e) => {
        e.preventDefault();
        if (!site_title) {
            setsite_title_err(true);
            return toast.error('Site title is required')
        }
        if (site_title_err) {
            return toast.error('Site title is required')
        }
        if (!navigation_title) {
            setnavigation_title_err(true);
            return toast.error('Navigation title is required')
        }
        if (navigation_title_err) {
            return toast.error('Navigation title is required')
        }
        setclicked(true);
        // let data = {
        //     navigation_title, navigationlogo, favicon, site_title
        // };
        // var setting = {};
        // setting.navigation_title = data.navigation_title;
        // setting.logo = data.navigationlogo;
        // setting.icon = data.favicon;
        // setting.site_title = data.site_title;
        let formData = new FormData();
        // formData.append('data', JSON.stringify(setting));
        formData.append('navigation_logo', navigationlogo);
        formData.append('favicon', favicon);
        formData.append('navigation_title', navigation_title);
        formData.append('site_title', site_title);
        formData.append('_id', selected_id);
        // let response = fetchData('/admin/settings/data', 'post', formData);
        let response = fetchData('/admin/update/settings/by_id', 'post', formData);
        response.then((res) => {
            setclicked(false);
            if (res && res.data && +res.data.status === 0) {
                if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                    res.data.errors.map((item) => {
                        return toast.error(item.msg);
                    })
                } else {
                    toast.error(res.data.response);
                }
            } else {
                if (res && res.data && +res.data.status === 1) {
                    toast.success(res.data.response);
                    window.scrollTo(0, 0)
                    setTimeout(() => {
                        getData(selected_id);
                    }, 1000);
                }
            }
        }).catch((err) => {
            console.log("err", err)
            return toast.error('Something went wrong');
        })
    };

    let getData = _id => {
        if (_id && _id.length > 0 && String(_id) !== String(undefined)) {
            setselected_id(_id)
            // let response = fetchData('/admin/settings/getdata', 'post', { _id });
            let response = fetchData('/admin/settings/getdata/by_id', 'post', { _id });
            response.then((res) => {
                if (res && res.data && +res.data.status === 0) {
                    if (res.data.errors && res.data.errors.length > 0 && Array.isArray(res.data.errors)) {
                        res.data.errors.map((item) => {
                            return toast.error(item.msg);
                        })
                    }
                } else {
                    if (res && res.data && +res.data.status === 1) {
                        if (res.data.response.navigation_logo) {
                            setnavigationlogo(`${CONFIG}/${res.data.response.navigation_logo}`);
                            showsetnavigationlogo(true);
                        }
                        if (res.data.response.favicon) {
                            setfavicon(`${CONFIG}/${res.data.response.favicon}`);
                            showsetfavicon(true);
                        }
                        if (res.data.response && res.data.response.navigation_title) {
                            setnavigation_title(res.data.response.navigation_title);
                        }
                        if (res.data.response && res.data.response.site_title) {
                            setsite_title(res.data.response.site_title);
                        }
                    }
                }
            }).catch((err) => {
                console.log("err", err)
                return toast.error('Something went wrong');
            });
        }
    }


    useEffect(() => {
        if (sessionStorage.getItem('user_id') && sessionStorage.getItem('user_id').length > 0 && sessionStorage.getItem('user_id') !== undefined && sessionStorage.getItem('user_id') !== null) {
            getData(sessionStorage.getItem('user_id'))
        }
    }, []);

    useEffect(() => {
        let length = window.location.host.split('.');
        if (length && length.length > 1) {
            if (!sessionStorage.getItem('user_sub_domain')) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                sessionStorage.removeItem('user_sub_domain')
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(sessionStorage.getItem('user_sub_domain'))) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            } else if (sessionStorage.getItem('set_domain') !== String(length[0])) {
                sessionStorage.removeItem('set_domain');
                sessionStorage.removeItem('user_sub_domain')
                sessionStorage.removeItem('user_id');
                sessionStorage.removeItem('SGH');
                return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
            }
        } else {
            sessionStorage.removeItem('set_domain');
            return window.location.replace(`${window.location.protocol}//${window.location.host}/login`);
        }
    }, []);


    return (
        <>
            <ToastContainer position="top-right" autoClose={2500} closeOnClick />
            <div className="flex flex-row mb-4">
                <div className="w-full">
                    <nav className="w-full flex">
                        <ol className="list-none flex flex-row items-center justify-start">
                            {home && (
                                <li className="mr-2 flex items-center">
                                    <FiHome className="h-3 w-3 stroke-current" />
                                </li>
                            )}
                            {items.map((item, i) => (
                                <li className="flex items-center" key={i}>
                                    <Link href={item.url}>
                                        <a className="mr-2">{item.title}</a>
                                    </Link>
                                    {!item.last && icon === 'arrow' && (
                                        <FiArrowRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevron' && (
                                        <FiChevronRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                    {!item.last && icon === 'chevrons' && (
                                        <FiChevronsRight className="h-3 w-3 mr-2 stroke-current" />
                                    )}
                                </li>
                            ))}
                        </ol>
                    </nav>
                </div>
            </div>
            <Widget title="">
                <form>
                    <div className="flex flex-col lg:flex-row lg:flex-wrap w-full lg:w-1/2">
                        <div className="w-full mt-3 mb-6">
                            <div className={`form-element`}>
                                <div className="form-label">Navigation Title <span className="form-error"></span></div>
                                <input
                                    name="navigation_title"
                                    type="text"
                                    className={`form-input form-input-${navigation_title_err ? 'invalid' : 'valid'}`}
                                    placeholder="Navigation Title"
                                    value={navigation_title}
                                    onChange={e => onChange(e, 'navigation_title')}
                                />
                                {navigation_title_err ? <div className="form-error">Navigation title is required</div> : null}
                            </div>
                            <div className={`form-element`}>
                                <div className="form-label">Site Title <span className="form-error"></span></div>
                                <input
                                    name="site_title"
                                    type="text"
                                    className={`form-input form-input-${site_title_err ? 'invalid' : 'valid'}`}
                                    placeholder="Site Title"
                                    value={site_title}
                                    onChange={e => onChange(e, 'site_title')}
                                    required={true}
                                />
                                {site_title_err ? <div className="form-error">Site title is required</div> : null}
                            </div>
                        </div>
                        <div className="w-full  mt-3 mb-6">
                            <div className={`form-element`}>
                                <div className="form-label">Navigation Logo</div>
                                <input type="file" onChange={e => onFileChange(e, 'logo')}></input>
                            </div>
                        </div>
                        {
                            shownavigationlogo ?
                                <>
                                    <img src={navigationlogo} width={200} height={200}></img>
                                </>
                                : null
                        }
                        <div className="w-full  mt-3 mb-6">
                            <div className={`form-element`}>
                                <div className="form-label">Favicon</div>
                                <input type="file" onChange={e => onFileChange(e, 'favicon')}></input>
                            </div>
                        </div>
                        {
                            showfavicon ?
                                <>
                                    <img src={favicon} width={200} height={200}></img>
                                </>
                                : null
                        }
                    </div>
                    {clicked ?
                        <button
                            className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                            style={{ cursor: 'progress' }}
                            disabled={clicked}
                            style={{ marginTop: '15px', marginLeft: '445px' }} >{'Update'} </button>
                        :
                        <button
                            className="btn btn-default bg-blue-500 hover:bg-blue-600 text-white btn-rounded"
                            onClick={e => submit(e)}
                            style={{ marginTop: '15px', marginLeft: '445px' }}   >Update </button>
                    }
                </form>
            </Widget>


        </>
    );
};
export default Index